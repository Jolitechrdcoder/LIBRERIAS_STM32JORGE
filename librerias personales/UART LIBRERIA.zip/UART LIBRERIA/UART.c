
/*
 * Uart.c
 *
 *  Created on: Jun 8, 2023
 *      Author: mecat
 */
#include "UART.h"
char *buff;
uint8_t Rx;
extern UART_HandleTypeDef huart2;
void Uart_init(char *string)
{
	buff=string;
	HAL_UART_Receive_IT(&huart2, &Rx,1);
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	static int i=0;
		 if(Rx=='\n')
		 {
			 buff[i]='\0';
			 i=0;
		 }
		 else if(i<100)
		 {
			 buff[i]=Rx;
			 i++;
		 }
		 else
		 {
			 i=0;
		 }

		HAL_UART_Receive_IT(&huart2,&Rx,1);

}
void Transmit(UART_HandleTypeDef huart,char *pData)
{
	HAL_UART_Transmit(&huart,(uint8_t*)pData,strlen(pData),HAL_MAX_DELAY);
}


