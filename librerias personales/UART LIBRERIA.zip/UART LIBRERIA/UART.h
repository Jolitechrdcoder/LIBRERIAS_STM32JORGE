/*
 * uart.h
 *
 *  Created on: Jun 8, 2023
 *      Author: mecat
 */

#ifndef INC_UART_H_
#define INC_UART_H_

#include "stm32f3xx_hal.h"
#include "string.h"
#define BUFF_SIZE 100
void Transmit(UART_HandleTypeDef huart,char *pData);
void Uart_init(char *string);

#endif /* INC_UART_H_ */


